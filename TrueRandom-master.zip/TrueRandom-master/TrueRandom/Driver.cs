﻿using Microsoft.Quantum.Simulation.Simulators;
using System;
using System.Collections.Generic;
using QConvert = Microsoft.Quantum.Convert;

namespace Quantum.TrueRandom
{
	class Driver
	{
		static void Main(string[] args)
		{
			List<uint> numbers = new List<uint>();
			Console.WriteLine("True Random Loto !");
			Console.WriteLine("Press any key to perform a draw !");
			uint maxSort = 6;

			while (true)
			{
				Console.ReadKey();
				while (numbers.Count < maxSort)
				{
					byte[] int32Array = new byte[4];
					for (int i = 0; i < int32Array.Length; i++)
					{
						using (var qsim = new QuantumSimulator())
						{
							bool[] byteResult = new bool[8];
							for (int j = 0; j < byteResult.Length; j++)
							{
								var qResult = Superposition.Run(qsim).Result;
								byteResult[j] = QConvert.ResultAsBool.Run(qsim, qResult).Result;
							}

							int index = 8 - byteResult.Length;
							byte result = 0;

							foreach (bool b in byteResult)
							{
								if (b)
								{
									result |= (byte)(1 << (7 - index));
								}
								index++;
							}
							int32Array[i] = result;
						}
					}

					double seed = 49;
					uint number = BitConverter.ToUInt32(int32Array, 0) - 1;
					uint value = Convert.ToUInt32((Convert.ToDouble(number) / Convert.ToDouble(uint.MaxValue)) * seed);

					if (value != 0
						&& !numbers.Contains(value))
					{
						numbers.Add(value);
					}
				}
				Console.WriteLine($"{numbers[0]}, {numbers[1]}, {numbers[2]}, {numbers[3]}, {numbers[4]}, {numbers[5]}");
				numbers.Clear();
			}
		}
	}
}