// JavaScript sample
let name = "mushroom"
let 🍄 = () => "👋 Hello World 🌍"
